sum = lambda a,b : a + b
print( sum(10 , 7) )

multi = lambda c,d : c * d
print( multi(10 , 7))

power = lambda e , f : e ** f
print(power(10 , 2))

division = lambda g , h : g // h
print (division (10 , 2))