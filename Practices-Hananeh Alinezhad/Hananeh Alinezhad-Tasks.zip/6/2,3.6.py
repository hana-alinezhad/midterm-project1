duobled_numbers = map (lambda x : x * 2 , [10 , 20 , 30 , 40 ])
print("duobled numbers:")
for numbers in duobled_numbers:
    print(numbers)
    
power_two = map (lambda x : x ** 2 , [2 , 3 , 4 , 5 , 6 , 7])
print("power two:")
for numbers in power_two:
    print(numbers)
    