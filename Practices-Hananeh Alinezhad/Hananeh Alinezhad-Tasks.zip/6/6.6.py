numbers_greater_than_10 = filter(lambda x: x > 10 , [1 , 2, 7, 70 , 12])
for numbers in numbers_greater_than_10 :
    print(numbers)
    