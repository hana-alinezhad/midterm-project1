def a():
    s = " Hello world "
    print(s)
s = " It's me"
a()
print(s)