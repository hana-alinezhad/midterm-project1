def a():
    s = "Hello world"
    print(s)
    
a()
print(s)